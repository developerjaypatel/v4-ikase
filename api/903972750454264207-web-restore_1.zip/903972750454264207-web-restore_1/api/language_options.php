                  <option value="" selected="selected">Select from List</option>
                  <option value="English" <% if(language=="English") {%>selected<% } %>>English</option>
                  <option value="Spanish" <% if(language=="Spanish") {%>selected<% } %>>Spanish</option>
                  <option value="—————————————" disabled="disabled">—————————————</option>
                  <option value="Armenian" <% if(language=="Armenian") {%>selected<% } %>>Armenian</option>
                  <option value="Cambodian" <% if(language=="Cambodian") {%>selected<% } %>>Cambodian</option>
                  <option value="English/Spanish" <% if(language=="English/Spanish") {%>selected<% } %>>English/Spanish</option>
                  <option value="Farsi" <% if(language=="Farsi") {%>selected<% } %>>Farsi</option>
                  <option value="French" <% if(language=="French") {%>selected<% } %>>French</option>
                   <option value="Italian" <% if(language=="Italian") {%>selected<% } %>>Italian</option>
                  <option value="Korean" <% if(language=="Korean") {%>selected<% } %>>Korean</option>
                  <option value="Portuguese" <% if(language=="Portuguese") {%>selected<% } %>>Portuguese</option>
                  <option value="Punjabi" <% if(language=="Punjabi") {%>selected<% } %>>Punjabi</option>
                  <option value="Tagalog" <% if(language=="Tagalog") {%>selected<% } %>>Tagalog</option>
                  <option value="Vietnamese" <% if(language=="Vietnamese") {%>selected<% } %>>Vietnamese</option>