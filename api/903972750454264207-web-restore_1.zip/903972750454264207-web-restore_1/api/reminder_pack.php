<?php
/*
event scheduled
reminder scheduled, attach to event
reminder triggered, create message, attach message to event, put message in buffer
message sent, buffer delete
*/
?>