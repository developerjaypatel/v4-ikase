<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p><a href="scrape_calendar.php">scrape</a></p>
<p><a href="scrape_convert_xl.php">convert</a> xl to csv</p>
<p><a href="scrape_read_csv.php">read</a> csv into sql</p>
<p><a href="scrape_expand_csv.php">expand</a> multiple firms into single</p>
<p><a href="scrape_transfer_csv.php">transfer</a> into court calendar for pending</p>
</body>
</html>