                  <option value="" selected="selected">Select from List</option>
                  <option value="English">English</option>
                  <option value="Spanish">Spanish</option>
                  <option value="—————————————" disabled="disabled">—————————————</option>
                  <option value="Cambodian">Cambodian</option>
                  <option value="English/Spanish">English/Spanish</option>
                  <option value="Farsi">Farsi</option>
                  <option value="French">French</option>
                   <option value="Italian">Italian</option>
                  <option value="Korean">Korean</option>
                  <option value="Portuguese">Portuguese</option>
                  <option value="Tagalog">Tagalog</option>
                  <option value="Vietnamese">Vietnamese</option>