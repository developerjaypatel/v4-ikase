<?php
include("manage_session.php");

die(print_r($_SESSION));
?>