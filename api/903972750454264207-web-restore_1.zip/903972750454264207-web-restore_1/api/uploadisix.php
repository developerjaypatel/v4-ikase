<?php
header("location:https://www.ikase.xyz/ikase/limapi/uploadifive.php");
?>