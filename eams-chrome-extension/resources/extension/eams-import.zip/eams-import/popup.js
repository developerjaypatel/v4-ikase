let scrapeData = document.getElementById("scrapeData");
let fillRequesterInformation = document.getElementById("fillRequesterInformation");
let showData = document.getElementById("showData");
let saveData = document.getElementById("saveData");
let getData = document.getElementById("getData");

scrapeData.addEventListener("click",async ()=>{
	// get the current active tab
	let [tab] = await chrome.tabs.query({
		active:true,currentWindow: true
	});

	// execute script 
	chrome.scripting.executeScript({
		target: {tabId: tab.id},
		func: scrapeDataFromPage,
	});
})

var data_adj;
function scrapeDataFromPage()
{
	data_adj = "";
	var web_url = location.href;
	if(web_url.includes("matrixdocuments.com/dis/pws/quicks/orders/location_edit.php"))
	{
		data_adj = document.querySelectorAll('a')[51].textContent;
	}
	else if(web_url.includes("matrixdocuments.com/dis/pws/quicks/orders/import_adj.php"))
	{
		data_adj = document.querySelector('#adj_number_eams').value;
	}
	else if(web_url.includes("matrixdocuments.com/dis/pws/manage/request/editor.php"))
	{
		data_adj = document.querySelector('#case_number').value;
	}
	else if(web_url.includes("ikase.org/v8.php#kase"))
	{
		data_adj = document.querySelector('.kase_adj_number').textContent;
	}
	else if(web_url.includes("ikase.org/v8.php"))
	{
		data_adj = document.querySelector('#scrape_adj_number').value;
	}
	else
	{
		alert("Invalid page!");
		return false;
	}
	
	if(!data_adj.includes("ADJ"))
	{
		alert("Invalid ADJ number!")
		return false;
	}

	chrome.storage.sync.set({"data_adj":data_adj},function(){
		// alert(data_adj + " has been saved!");
		console.log(data_adj);

		// window.open('https://eams.dwc.ca.gov/WebEnhancement/RequesterInformationCaptureScreen.jsp', '_blank');
		window.open('https://eams.dwc.ca.gov/WebEnhancement/InjuredWorkerSearchScreen.jsp', '_blank');

	});
}

fillRequesterInformation.addEventListener("click",async ()=>{
	// alert("Hello");

	// get the current active tab
	let [tab] = await chrome.tabs.query({
		active:true,currentWindow: true
	});

	// execute script 
	chrome.scripting.executeScript({
		target: {tabId: tab.id},
		func: fillInformation,
	});
})

function fillInformation()
{
	var web_url = location.href;
	if(!web_url.includes("eams.dwc.ca.gov/WebEnhancement/RequesterInformationCaptureScreen.jsp"))
	{
		alert("Invalid page!");
		return false;
	}

	document.querySelectorAll('input')[2].value = "THOMAS";
	document.querySelectorAll('input')[3].value = "SMITH";
	document.querySelectorAll('input')[5].value = "MATRIXDIS@GMAIL.COM";
	document.querySelectorAll('select')[0].value = "CASESEARCH";
}

showData.addEventListener("click",async ()=>{
	
	let [tab] = await chrome.tabs.query({
		active:true,currentWindow: true
	});

	// execute script 
	chrome.scripting.executeScript({
		target: {tabId: tab.id},
		func: showDataToPage,
	});
})

async function showDataToPage()
{
	var web_url = location.href;
	if(!web_url.includes("eams.dwc.ca.gov/WebEnhancement/InjuredWorkerSearchScreen.jsp"))
	{
		alert("Invalid page!");
		return false;
	}

	var url1,url2;
	chrome.storage.sync.get(["data_adj"], await function(items){
        console.log(items);
	    document.querySelectorAll("input")[0].value = items.data_adj;

	    // document.querySelectorAll("input")[8].click();

	    var resp_data;

	    var url = "https://eams.dwc.ca.gov/WebEnhancement/InjuredWorkerFinder?caseNumber="+ items.data_adj +"&action=Search";
		var r = new XMLHttpRequest();
		r.open("GET", url, true);
		r.onreadystatechange = function () {
		  if (r.readyState != 4 || r.status != 200) {
			resp_data = r.responseText;
		  } else {
			resp_data = r.responseText;
			resp_data = new DOMParser().parseFromString(resp_data, "text/html");

			var tab = resp_data.querySelectorAll("table");
			var tr = tab[1].querySelectorAll("tr");
			var td = tr[1].querySelectorAll("td");
			var city = td[2].textContent;
			var zip = td[3].textContent;
			var table7 = new Array(city,zip);
			// alert(table7);

			if(resp_data.querySelectorAll("a")[3]!="")
			{
				url1 = resp_data.querySelectorAll("a")[3];
				// alert(url1);

				//--- start call url1

				var r1 = new XMLHttpRequest();
				r1.open("GET", url1, true);
				r1.onreadystatechange = function () {
				  if (r1.readyState != 4 || r1.status != 200) {
					// resp_data1 = r1.responseText;
				  } else {
					// resp_data1 = r1.responseText;
					// resp_data1 = new DOMParser().parseFromString(resp_data, "text/html");					
					
				  	var url2 = "https://eams.dwc.ca.gov/WebEnhancement/CaseDetailFinder?arrayIndex=0&startIndex=0";

					// window.open(url2,"_blank");
				  
					//--- start call url2
					var r2 = new XMLHttpRequest();
					r2.open("GET", url2, true);
					r2.onreadystatechange = function () {
					  if (r2.readyState != 4 || r2.status != 200) {
						resp_data2 = r2.responseText;
					  } else {
						resp_data2 = r2.responseText;
						resp_data2 = new DOMParser().parseFromString(resp_data2, "text/html");

						// --- start save data
						var table = resp_data2.querySelectorAll('.resultTable');

						var data = "<h2 align='left'>Case Detail Information</h2>";

						for(var i=0;i<table.length;i++)
						{
							data = data + "<table class='eams_tables_data' align='center' style='margin:5px;background-color:#fff;' border='1px' cellpadding='5px' bgcolor='#f1f1f1'>" + table[i].innerHTML + "</table>";
						}

						// --- start view events call - url3
						var url3 = "https://eams.dwc.ca.gov/WebEnhancement/CaseEventFinder?arrayIndex=0&startIndex=0";		
						var r3 = new XMLHttpRequest();
						r3.open("GET", url3, true);
						r3.onreadystatechange = function () {
						  if (r3.readyState != 4 || r3.status != 200) {
							var resp_data3 = r3.responseText;
						  } else {
							var resp_data3 = r3.responseText;
							resp_data3 = new DOMParser().parseFromString(resp_data3, "text/html");
							var table_events = resp_data3.querySelectorAll('.resultTable');
							var data_events = "<h2 align='left'>Case Events</h2>";
							for(var i=0;i<table_events.length;i++)
							{
								data_events = data_events + "<table class='eams_tables_data' align='center' style='margin:5px;background-color:#fff;' border='1px' cellpadding='5px' bgcolor='#f1f1f1'>" + table_events[i].innerHTML + "</table>";
							}

							// --- start reduce button 4 code
							data = data + "" + data_events;							
							const element = document.createElement('div');						
							element.style.position = "absolute";
							element.style.top = "0px";
							element.style.left = "0px";
							element.style.right = "0px";
							element.style.background = "#f1f1f1";
							element.style.padding = "5px";
							element.innerHTML = data;
							document.body.appendChild(element);
							// --- end reduce button 4 code

							// --- start fetch data in arr -----------------------------------
							tables = table[0].querySelectorAll('tr')[1];
							var table1 = new Array();
							for(i=0;i<tables.querySelectorAll('td').length;i++)
							{
								table1[i] = tables.querySelectorAll('td')[i].textContent;

								if(i==4 || i==5)
								{
									var tmp = tables.querySelectorAll('td')[i].innerHTML;
									if(tmp.includes("checked"))
									{
										table1[i] = "Y";
									}
									else
									{
										table1[i] = "N";
									}
								}
							}
							// alert(table1);

							tables = table[1].querySelectorAll('tr')[1];
							var table2 = new Array();
							for(i=0;i<tables.querySelectorAll('td').length;i++)
							{
								table2[i] = tables.querySelectorAll('td')[i].textContent;								
							}
							// alert(table2);

							var current = 2;
							var table6 = new Array();
							if(table.length == 5)
							{
								current++;
								tables = table[2].querySelectorAll('tr')[1];								
								for(i=0;i<tables.querySelectorAll('td').length;i++)
								{
									table6[i] = tables.querySelectorAll('td')[i].textContent;								
								}
							}

							var table3 = new Array();
							for(i=0;i<table[current].querySelectorAll('tr').length;i++)
							{
								tables = table[current].querySelectorAll('tr')[i];
								table3[i] = new Array();
								for(j=0;j<tables.querySelectorAll('td').length;j++)
								{
									table3[i][j] = tables.querySelectorAll('td')[j].textContent;	
								}
							}
							// alert(table3);

							current++;
							var table4 = new Array();
							for(i=1;i<table[current].querySelectorAll('tr').length;i++)
							{
								tables = table[current].querySelectorAll('tr')[i];
								var ii = i-1;
								table4[ii] = new Array();
								for(j=0;j<tables.querySelectorAll('td').length;j++)
								{
									table4[ii][j] = tables.querySelectorAll('td')[j].textContent;	
								}
							}
							// alert(table4);

							var table5 = new Array();
							for(i=1;i<table_events[1].querySelectorAll('tr').length;i++)
							{
								tables = table_events[1].querySelectorAll('tr')[i];
								var ii = i-1;
								table5[ii] = new Array();
								for(j=0;j<tables.querySelectorAll('td').length;j++)
								{
									table5[ii][j] = tables.querySelectorAll('td')[j].textContent;	
								}
							}
							// alert(table5);

							// --- end fetch data in arr ----------------------------------------
							
							//--- start call PHP code -------------------------------------------
							var formData = new FormData();
							formData.append("data1", JSON.stringify(table1));
							formData.append("data2", JSON.stringify(table2));
							formData.append("data3", JSON.stringify(table3));
							formData.append("data4", JSON.stringify(table4));
							formData.append("data5", JSON.stringify(table5));
							formData.append("data6", JSON.stringify(table6));
							formData.append("data7", JSON.stringify(table7));
							// var url_req = "http://localhost/eams-import/eams-import-save.php";
							var url_req = "https://matrixdocuments.com/eams-import/eams-import-save.php";
							var req = new XMLHttpRequest();
							req.open("POST", url_req, true);
							req.onreadystatechange = function () {
							  if (req.readyState != 4 || req.status != 200) {
								var data = req.responseText;
							  } else {
								var data = req.responseText;
							  }
							};
							req.send(formData);
							//--- end call PHP code ----------------------------------------------

							chrome.storage.sync.set({
							"data":data
							}
							,function(){
								// alert("Data has been saved!");
								// window.close();

							});
						  }
						};
						r3.send();
						// --- end view events call - url3

						// --- end save data						
					  }

					};
					r2.send();
					//--- end call url2


					//--- start send fetch data



					//--- end semd fetch data


				  }

				};
				r1.send();

				//--- end call url1
			}

		  }

		  console.log(resp_data);

		};
		r.send();
	});
}

saveData.addEventListener("click",async ()=>{
	// alert("Hello");

	// get the current active tab
	let [tab] = await chrome.tabs.query({
		active:true,currentWindow: true
	});

	// execute script 
	chrome.scripting.executeScript({
		target: {tabId: tab.id},
		func: saveDataFromPage,
	});
})

var data_tmp;
function saveDataFromPage()
{
	var table = document.querySelectorAll('.resultTable');

	var data = "";

	for(var i=0;i<table.length;i++)
	{
		data = data + "<table class='eams_tables_data' align='center' style='margin:5px;' border='1px' cellpadding='5px' bgcolor='#f1f1f1'>" + table[i].innerHTML + "</table>";
	}
	
	// alert(data.length);

	chrome.storage.sync.set({
		"data":data
	}
	,function(){
		alert("Data has been saved!");
		window.close();
		// getData.click();
	});
}

getData.addEventListener("click",async ()=>{
	// alert("Hello");
	
	// get the current active tab
	let [tab] = await chrome.tabs.query({
		active:true,currentWindow: true
	});

	// execute script 
	chrome.scripting.executeScript({
		target: {tabId: tab.id},
		func: getDataToPage,
	});
})

function getDataToPage()
{
	chrome.storage.sync.get(["data"], function(items){

        document.getElementById("eams_results").style.display = "block";
		document.getElementById("eams_results").style.zIndex  = "1";
		document.getElementById("eams_results").innerHTML = items.data + "<br/><a style='display:none;' href=javascript:notifyNoAttorney('"+ data_adj +"')>Notify Order Entry if Attorney not in EAMS</a><br/><br/><input type='button' value='Close' onclick='closeEAMS()' /><style>.eams_tables_data a{display:none;}</style>";

	});
}